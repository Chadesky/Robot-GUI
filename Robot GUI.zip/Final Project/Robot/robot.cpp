#include "robot.h"

Robot::Robot(QWidget *parent)
    : QWidget(parent)
{
    drawform();
    enumerateSerPorts();

    connect(changeCOM, SIGNAL(clicked()), this, SLOT(listCOM()));
    connect(connectbtn, SIGNAL(clicked()), this, SLOT(connectSer()));
    connect(disconnectbtn, SIGNAL(clicked()), this, SLOT(disconnectSer()));
    connect(turnon, SIGNAL(clicked()), this, SLOT(poweron()));
    connect(shutdown, SIGNAL(clicked()), this, SLOT(poweroff()));
    //connect(connectbtn, SIGNAL(clicked()), this, SLOT(checktemp(int)));
    //connect(connectbtn, SIGNAL(clicked()), this, SLOT(checksquirt(int)));
    //connect(connectbtn, SIGNAL(clicked()), this, SLOT(checktank(int)));
    connect(battery1, SIGNAL(valueChanged(int)), this, SLOT(checkbattery(int)));
    connect(battery2, SIGNAL(valueChanged(int)), this, SLOT(checklipo(int)));
    connect(serial,SIGNAL(errorOccurred(QSerialPort::SerialPortError)),this,SLOT(handleError(QSerialPort::SerialPortError)));
}

Robot::~Robot(){}

void Robot::drawform(void)
{
    serial = new QSerialPort();
    serlist = new QComboBox();
    setbaud = new QComboBox(); //lists Baud Rate options
    setbaud->addItem("115200");
    setbaud->addItem("57600");
    setbaud->addItem("38400");
    setbaud->addItem("19200");
    setbaud->addItem("9600");
    setbaud->addItem("4800");
    setbaud->addItem("2400");
    setbaud->addItem("1200");
    serstatus = new QLabel("Serial Port Status: unknown");


    mainhbox = new QHBoxLayout();
    powerbox = new QHBoxLayout();
    serialbox = new QHBoxLayout();
    waterbox = new QVBoxLayout();
    databox = new QVBoxLayout();
    connectbtn = new QPushButton("Connect"); //create connect button
    disconnectbtn = new QPushButton("Disconnect"); //create disconnect button
    shutdown = new QPushButton("SET TO 'NOT OPERATIONAL'"); //create off button
    turnon = new QPushButton("SET TO 'OPERATIONAL'"); //create on button
    changeCOM = new QPushButton("Change COM Port"); //refreshes the COM port list
    update = new QPushButton("Update Info"); //refreshes info from robot
    temp = new QLCDNumber(); //create temp value indicator
    temp->setDigitCount(3);
    squirt = new QLCDNumber(); //create squirted out water value indicator
    squirt->setDigitCount(4);
    watergraph = new QLCDNumber(); //create water volume left indicator //TEMP UNTIL I FIGURE OUT HOW TO MAKE INTO GRAPH
    watergraph->setDigitCount(5);
    battery1 = new QProgressBar();
    battery1->setMinimum(0);
    battery1->setMaximum(100);
    battery2 = new QProgressBar();
    battery2->setMinimum(0);
    battery2->setMaximum(100);
    battery1lbl = new QLabel("&Battery 1 Power Level");
    battery2lbl = new QLabel("&Battery 2 Power Level");
    squirtlbl = new QLabel("&Amount of Water Used");
    waterlbl = new QLabel("&Water in Tank");
    templbl = new QLabel("&Temperature Reading");

    //Setting and initialzing all lables with buddies
    battery1lbl->setText("Power left on: Alkaline Batteries");
    battery2lbl->setText("Power left on: Lipo Battery");
    battery1lbl->setBuddy(battery1);
    battery2lbl->setBuddy(battery2);
    squirtlbl->setText("Amount of Water Pumped Out");
    squirtlbl->setBuddy(squirt);
    templbl->setText("Highest Recorded Temperature");
    templbl->setBuddy(temp);
    waterlbl->setText("Water Volume Left in Tank");

    //Creating Widget Layout
    powerbox->addWidget(turnon);
    powerbox->addWidget(shutdown);
    serialbox->addWidget(connectbtn);
    serialbox->addWidget(disconnectbtn);
    serialbox->addWidget(serstatus);
    serialbox->addWidget(changeCOM);
    serialbox->addWidget(serlist);
    databox->addWidget(battery1lbl);
    databox->addWidget(battery1);
    databox->addWidget(battery2lbl);
    databox->addWidget(battery2);
    databox->addLayout(powerbox);
    databox->addLayout(serialbox);
    waterbox->addWidget(waterlbl);
    waterbox->addWidget(watergraph);
    waterbox->addWidget(squirtlbl);
    waterbox->addWidget(squirt);
    waterbox->addWidget(templbl);
    waterbox->addWidget(temp);
    waterbox->addWidget(update);
    mainhbox->addLayout(waterbox);
    mainhbox->addLayout(databox);
    this->setLayout(mainhbox);

    setWindowTitle("Robot Diagnosis"); //sets window title
}

void Robot::enumerateSerPorts(void){
    serinfo = QSerialPortInfo::availablePorts();
    //serlist->clear();
    //for(int i = 0 ; i < serinfo.length(); i++)
    //    serlist->addItem(serinfo[i].portName());
}
void Robot::checkrobot(void)
{
    char readdata[4];
    QByteArray s; s.append(0x80); s.append(0x86); s.append(0x81);
    qDebug() << "Sending: " << s.toHex() << endl;
    if(serial->isOpen())
    {
        serial->write(s, s.length());
        serial->waitForBytesWritten(-1);
        do
        {
            serial->waitForReadyRead(-1);
        }while(serial->bytesAvailable() < 3);
        serial->read(readdata, 4);
        serial->clear();
        qDebug() << "Received " + QByteArray(readdata, 4).toHex() << endl;

        uint8_t var = readdata[1];
        uint8_t var2 = readdata[2];
        watergraph->display(var);
        temp->display(var2);

        if( (unsigned char)readdata[3] == 0x81)
            qDebug() << "cmd succesful" << endl;
    }
    else {
        QMessageBox::warning(this, "Oops!", "Serial port is closed!");
    }
}
/*
void Robot::checktank(int){}

void Robot::checkbattery(int){}

void Robot::checklipo(int){}

void Robot::checktemp(int){}

void Robot::checksquirt(int){}
*/
void Robot::poweron(void)
{
    char readdata[3];
        QByteArray s; s.append(0x80); s.append(0x82); s.append(0x81);
        qDebug() << "Sending: " << s.toHex() << endl;
        if(serial->isOpen())
        {
            serial->write(s, s.length());
            serial->waitForBytesWritten(-1);
            do
            {
                serial->waitForReadyRead(-1);
            }while(serial->bytesAvailable() < 3);
            serial->read(readdata, 3);
            serial->clear();
            qDebug() << "Received " + QByteArray(readdata, 3).toHex() << endl;

            if( (unsigned char)readdata[3] == 0x81)
                qDebug() << "cmd succesful" << endl;
        }
        else {
            QMessageBox::warning(this, "Oops!", "Serial port is closed!");
        }
}

void Robot::poweroff(void)
{
    char readdata[3];
        QByteArray s; s.append(0x80); s.append(0x83); s.append(0x81);
        qDebug() << "Sending: " << s.toHex() << endl;
        if(serial->isOpen())
        {
            serial->write(s, s.length());
            serial->waitForBytesWritten(-1);
            do
            {
                serial->waitForReadyRead(-1);
            }while(serial->bytesAvailable() < 3);
            serial->read(readdata, 3);
            serial->clear();
            qDebug() << "Received " + QByteArray(readdata, 3).toHex() << endl;

            if( (unsigned char)readdata[3] == 0x81)
                qDebug() << "cmd succesful" << endl;
        }
        else {
            QMessageBox::warning(this, "Oops!", "Serial port is closed!");
        }
}

void Robot::connectSer(void)
{
    if(serinfo.count() == 0){ // if no ports are found...
        QMessageBox::warning(this,"Oops!","No Serial Port Found!!!");
    }
    else{//if at least one port is found...we will use the first port found
        serial->setPort(serinfo[serlist->currentIndex()]);
            if(serial->isOpen())//if port is already open...
                QMessageBox::warning(this,"Oops!","Serial port is already open. Please disconnect first");
            else{ //if port is available and not open...open it
                if (serial->open(QIODevice::ReadWrite) == false){
                    QMessageBox::warning(this,"Oops!","Failed to open port");
                    serial->close(); //if opening port failed close it
                }
                else {
                    //connect(update, SIGNAL(clicked()), this, SLOT(checktemp()));
                    //connect(update, SIGNAL(clicked()), this, SLOT(checksquirt()));
                    //connect(update, SIGNAL(clicked()), this, SLOT(checktank()));
                    connect(update, SIGNAL(clicked()), this, SLOT(checkrobot()));
                    //if port opened successfully....set its parameters
                    serial->setBaudRate(9600);
                    //serial->setBaudRate(tmp.toInt());//BaudRate //,QSerialPort::AllDirections);
                    serial->setDataBits(QSerialPort::Data8);// 8-bit data
                    serial->setParity(QSerialPort::NoParity); // no parity
                    serial->setFlowControl(QSerialPort::NoFlowControl); //no flow control
                    serial->setStopBits(QSerialPort::OneStop);// 1 stop bit
                    serstatus->setText("Port :" + serinfo[serlist->currentIndex()].portName() + " is open 9600 8-N-1."); //update status label
                }
            }
    }
}

void Robot::disconnectSer(void)
{
    if(serial->isOpen()==false)
         QMessageBox::warning(this,"Oops!","Serial port is already closed!");
    else{
        //disconnect(update, SIGNAL(clicked()), this, SLOT(checktemp()));
        //disconnect(update, SIGNAL(clicked()), this, SLOT(checksquirt()));
        //disconnect(update, SIGNAL(clicked()), this, SLOT(checktank()));
        disconnect(update, SIGNAL(clicked()), this, SLOT(checkrobot()));
        serial->close(); // close port
        serstatus->setText("Port :" + serinfo[serlist->currentIndex()].portName() + " is disconnected"); //update status label
    }
}

void Robot::handleError(QSerialPort::SerialPortError error)
{
    if(error != 0)
    {
        QMessageBox::warning(this,"Oops!","Serial port Error occured: " + QString::number(error));
        serial->close(); // close port
        serstatus->setText("Port :" + serinfo[serlist->currentIndex()].portName() + " is disconnected"); //update status label
    }
}

void Robot::listCOM(void){
    serlist->clear();
    for(int i = 0 ; i < serinfo.length(); i++ )
        serlist->addItem(serinfo[i].portName());
}
void Robot::changeBaud(void){
    tmp = setbaud->currentText();
}
