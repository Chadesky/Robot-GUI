#ifndef ROBOT_H
#define ROBOT_H

#include <QWidget>
#include <QtDebug>
#include <QHBoxLayout>
#include <QLCDNumber>
#include <QProgressBar>
#include <QPushButton>
#include <QLabel>
#include <QVBoxLayout>
#include <QMessageBox>
#include <QComboBox>
#include <QtCharts/QBarSet>
#include <QtCharts/QPieSeries>
#include <QtCharts/QPieSlice>
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>

QT_CHARTS_USE_NAMESPACE

class Robot : public QWidget
{
    Q_OBJECT

public:
    Robot(QWidget *parent = 0);
    ~Robot();
    void drawform(void); //draws the form
    void enumSerPorts(void); //finds all serial ports
public slots:
    void enumerateSerPorts(void);
    void checkrobot(void);
    /*
    void checktank(int); //checks volume of water left in tank
    void checkbattery(int); //checks battery left in alkaline batteries
    void checklipo(int); //checks battery left in lipo battery
    void checktemp(int);
    void checksquirt(int);
    */
    void poweroff(void); //turns off robot
    void poweron(void); //turns on robot
    void connectSer(void); //connects robot to serial
    void disconnectSer(void); //disconnects robot from serial
    void handleError(QSerialPort::SerialPortError);
    void listCOM(void); //lists all the COM ports available
    void changeBaud(void); //lists the baud rate options

private:
    QSerialPort *serial; //declare required pointers/variables
    QList<QSerialPortInfo> serinfo; //implicitly shared object
    QHBoxLayout *mainhbox, *powerbox, *serialbox;
    QVBoxLayout *waterbox, *databox;
    QProgressBar *battery1, *battery2;
    QLCDNumber *temp, *squirt, *watergraph;
    QPushButton *shutdown, *turnon, *connectbtn, *disconnectbtn, *changeCOM, *update;
    QLabel *battery1lbl, *battery2lbl, *waterlbl, *templbl, *squirtlbl, *serstatus;
    //QPieSeries *watergraph;
    QMessageBox *waterwarn, *batterywarn;
    QComboBox *serlist, *setbaud;
    QString tmp;
};

#endif // ROBOT_H
